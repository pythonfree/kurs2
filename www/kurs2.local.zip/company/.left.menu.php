<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?
$aMenuLinks = Array(
	Array(
		"О компании", 
		"./", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Руководство", 
		"management.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Миссия и стратегия", 
		"mission.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"История", 
		"history.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Вакансии (Компонент)",
		"vacancies.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Вакансии (Комплексный компонент)",
		"/vacancies/",
		Array(),
		Array(),
		""
	)
);
?>
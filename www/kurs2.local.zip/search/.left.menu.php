<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?
$aMenuLinks = Array(
	Array(
		"Поиск", 
		"./", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Карта сайта", 
		"map.php", 
		Array(), 
		Array(), 
		"" 
	)
);
?>
<?php

define('CONTENT_EDITOR_GROUP_ID', 5);//ID группы контент-редакторы
define('ACTIONS_IBLOCK_ID', 5);//ИБ Акции
define('CATALOG_IBLOCK_ID', 2);//ИБ Продукция
define('NEWS_IBLOCK_ID', 1);//ИБ Новости
define('GROUP_ADMIN_ID', 1);//Группа администраторов
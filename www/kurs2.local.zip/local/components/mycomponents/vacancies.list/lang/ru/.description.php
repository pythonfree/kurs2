<?
$MESS ['T_IBLOCK_DESC_LINE'] = "Вакансии";
$MESS ['T_IBLOCK_DESC_LINE_DESC'] = "Список вакансий";
$MESS ['T_IBLOCK_DESC_NEWS'] = "Дополнительные";
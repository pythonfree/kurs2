<?
$MESS ['AUTH_CHANGE_PASSWORD'] = "Смена пароля";
$MESS ['AUTH_LOGIN'] = "Логин";
$MESS ['AUTH_CHECKWORD'] = "Контрольная строка";
$MESS ['AUTH_NEW_PASSWORD'] = "Новый пароль";
$MESS ['AUTH_NEW_PASSWORD_CONFIRM'] = "Подтверждение пароля";
$MESS ['AUTH_CHANGE'] = "Изменить пароль";
$MESS ['AUTH_REQ'] = "Обязательные поля";
$MESS ['AUTH_AUTH'] = "Авторизация";
$MESS ['AUTH_NEW_PASSWORD_REQ'] = "Новый пароль";
$MESS ['AUTH_CAPTCHA_PROMT'] = "Код на картинке";
?>
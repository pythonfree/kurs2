<?
$MESS ['AUTH_LOGIN'] = "Логин";
$MESS ['AUTH_PASSWORD'] = "Пароль";
$MESS ['AUTH_REMEMBER_ME'] = "Запомнить меня";
$MESS ['AUTH_AUTHORIZE'] = "Войти";
$MESS ['AUTH_REGISTER'] = "Регистрация";
$MESS ['AUTH_FIRST_ONE'] = "Если вы впервые на сайте, заполните пожалуйста ";
$MESS ['AUTH_REG_FORM'] = "регистрационную форму.";
$MESS ['AUTH_FORGOT_PASSWORD_2'] = "Забыли свой пароль?";
$MESS ['AUTH_GO'] = "Следуйте ";
$MESS ['AUTH_GO_AUTH_FORM'] = "на форму для запроса пароля.";
$MESS ['AUTH_MESS_1'] = "После получения контрольной строки следуйте на ";
$MESS ['AUTH_CHANGE_FORM'] = "форму для смены пароля.";
$MESS ['AUTH_A_INTERNAL'] = "Встроенная авторизация";
$MESS ['AUTH_A_OPENID'] = "OpenID";
$MESS ['AUTH_OPENID'] = "OpenID";
$MESS ['AUTH_A_LIVEID'] = "LiveID";
$MESS ['AUTH_LIVEID_LOGIN'] = "Log In";
$MESS ['AUTH_CAPTCHA_PROMT'] = "Код на картинке";
$MESS["AUTH_SECURE_NOTE"]="Перед отправкой формы авторизации пароль будет зашифрован в браузере. Это позволит избежать передачи пароля в открытом виде.";
$MESS["AUTH_NONSECURE_NOTE"]="Пароль будет отправлен в открытом виде. Включите JavaScript в браузере, чтобы зашифровать пароль перед отправкой.";
?>
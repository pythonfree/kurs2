<?
$MESS ['CATALOG_BACK'] = "Назад в раздел";
$MESS ['CATALOG_CHAR'] = "Характеристики";
$MESS['CR_PRICE'] = 'Цена';
?>
<?
$MESS["CATALOG_BACK"] = "Back to Section";
$MESS["CATALOG_CHAR"] = "Parameters";
$MESS["CR_PRICE"] = "Price";
?>
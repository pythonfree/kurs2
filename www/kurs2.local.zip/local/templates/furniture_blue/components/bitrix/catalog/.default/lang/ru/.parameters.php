<?
$MESS['SHOW_PICTURE_DETAIL'] = "Показывать изображение";
$MESS['SHOW_PARENT_NAME'] = "Показывать заголовок раздела";
?>
<?
$MESS["MEWS_DETAIL_LINK"] = "Details";
$MESS["NEWS_DELETE_CONFIRM"] = "Are you sure you want to delete this \"#ELEMENT#\"?";
?>
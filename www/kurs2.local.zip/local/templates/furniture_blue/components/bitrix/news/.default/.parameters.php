<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arTemplateParameters["LIST_PREV_PICT_H"] = [
	"NAME" => GetMessage("LIST_PREV_PICT_H"),
	"TYPE" => "STRING",
	"DEFAULT" => "50",
];
$arTemplateParameters["LIST_PREV_PICT_W"] = [
	"NAME" => GetMessage("LIST_PREV_PICT_W"),
	"TYPE" => "STRING",
	"DEFAULT" => "50",
];

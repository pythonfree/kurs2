<?
$MESS ['T_NEWS_DETAIL_BACK'] = "Назад к списку новостей";
$MESS ['CATEGORIES'] = "Материалы по теме:";
?>
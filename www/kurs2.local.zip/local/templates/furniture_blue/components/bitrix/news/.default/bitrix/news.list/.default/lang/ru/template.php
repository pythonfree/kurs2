<?
$MESS['MEWS_DETAIL_LINK'] = 'Читать дальше';
$MESS ['NEWS_DELETE_CONFIRM'] = 'Вы уверены, что хотите удалить новость?';
?>
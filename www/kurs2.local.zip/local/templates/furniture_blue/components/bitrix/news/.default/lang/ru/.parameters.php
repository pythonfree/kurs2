<?
$MESS["LIST_PREV_PICT_H"] = "Высота анонсовой картинки";
$MESS["LIST_PREV_PICT_W"] = "Ширина анонсовой картинки";
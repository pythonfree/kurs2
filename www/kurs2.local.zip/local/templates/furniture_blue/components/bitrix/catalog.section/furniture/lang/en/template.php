<?
$MESS["CATALOG_BUY"] = "Buy";
$MESS["CATALOG_ADD"] = "Add to cart";
$MESS["CATALOG_COMPARE"] = "Compare";
$MESS["CATALOG_NOT_AVAILABLE"] = "(not available from stock)";
$MESS["CATALOG_QUANTITY"] = "Quantity";
$MESS["CATALOG_QUANTITY_FROM_TO"] = "from #FROM# to #TO#";
$MESS["CATALOG_QUANTITY_FROM"] = "#FROM# and more";
$MESS["CATALOG_QUANTITY_TO"] = "up to #TO#";
$MESS["CT_BCS_QUANTITY"] = "Quantity";
$MESS["CATALOG_ELEMENT_DELETE_CONFIRM"] = "Are you sure you want to delete this \"#ELEMENT#\"?";
?>
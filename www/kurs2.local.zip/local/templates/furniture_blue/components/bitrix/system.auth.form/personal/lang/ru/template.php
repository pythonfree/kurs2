<?
$MESS ["AUTH_LOGIN_BUTTON"] = "Авторизоваться";
$MESS ["AUTH_CLOSE_WINDOW"] = "Закрыть";
$MESS ["AUTH_LOGIN"] = "Логин";
$MESS ["AUTH_PASSWORD"] = "Пароль";
$MESS ["AUTH_REMEMBER_ME"] = "Запомнить меня на этом компьютере";
$MESS ["AUTH_FORGOT_PASSWORD_2"] = "Забыли свой пароль?";
$MESS ["AUTH_REGISTER"] = "Регистрация";
$MESS ["AUTH_LOGOUT_BUTTON"] = "Выйти";
$MESS ["AUTH_PROFILE"] = "Мой профиль";
?>
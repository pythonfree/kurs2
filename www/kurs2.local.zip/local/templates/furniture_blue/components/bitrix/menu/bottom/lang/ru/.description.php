<?
$MESS ['MENU_TREE_NAME'] = "Нижнее меню";
$MESS ['MENU_TREE_DESC'] = "Нижнее меню";
?>
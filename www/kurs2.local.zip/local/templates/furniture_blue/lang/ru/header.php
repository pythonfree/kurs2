<?
$MESS["CFT_MAIN"] = "На главную страницу";
$MESS["CFT_SEARCH"] = "Поиск";
$MESS["CFT_FEEDBACK"] = "Обратная связь";
$MESS["CFT_NEWS"] = "Новости компании";
$MESS["MATERIALS_SECTION"] = "Список материалов";
$MESS["CFT_FEATURED"] = "Спецпредложение";
?>
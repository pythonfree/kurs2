<?
$MESS["CFST_TEMPLATE_NAME"] = "Фиксированный";
$MESS["CFST_TEMPLATE_DESC"] = "Легкий и светлый шаблон с фиксированной шириной.";
?>
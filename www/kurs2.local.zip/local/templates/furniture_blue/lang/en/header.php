<?
$MESS["CFT_MAIN"] = "Main Page";
$MESS["CFT_SEARCH"] = "Search";
$MESS["CFT_FEEDBACK"] = "Feedback";
$MESS["CFT_NEWS"] = "Company News";
$MESS["CFT_FEATURED"] = "Special Offer";
?>
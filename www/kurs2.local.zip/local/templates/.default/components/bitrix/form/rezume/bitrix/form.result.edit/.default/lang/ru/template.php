<?
$MESS ['FORM_CHANGE_TO'] = "сменить на";
$MESS ['FORM_CURRENT_STATUS'] = "Текущий статус: ";
$MESS ['FORM_ENLARGE'] = "Увеличить";
$MESS ['FORM_REQUIRED_FIELDS'] = "Поля, обязательные для заполнения";
$MESS ['FORM_APPLY'] = "Применить";
$MESS ['FORM_SAVE'] = "Сохранить";
$MESS ['FORM_RECORD_NOT_FOUND'] = "Запись не найдена";
$MESS ['FORM_RESULT_ACCESS_DENIED'] = "Не хватает прав для доступа к результату.";
$MESS ['FORM_ACCESS_DENIED'] = "Не хватает прав доступа к веб-форме.";
$MESS ['FORM_DATA_SAVED'] = "Данные успешно сохранены.";
$MESS ['FORM_VIEW'] = "Просмотр";
$MESS ['FORM_PRINT'] = "Печать";
$MESS ['FORM_FORM_NAME'] = "Форма:";
$MESS ['FORM_DATE_CREATE'] = "Создан:";
$MESS ['FORM_TIMESTAMP'] = "Изменен:";
$MESS ['FORM_USER'] = "Пользователь:";
$MESS ['FORM_EDIT_USER'] = "Профайл пользователя";
$MESS ['FORM_NOT_AUTH'] = "(не авторизован)";
$MESS ['FORM_NOT_REGISTERED'] = "(не зарегистрирован)";
$MESS ['FORM_GUEST'] = "Посетитель:";
$MESS ['FORM_GUEST_ALT'] = "Профайл посетителя";
$MESS ['FORM_SESSION'] = "Сессия:";
$MESS ['FORM_MODULE_NOT_INSTALLED'] = "Модуль веб-форм не установлен.";
$MESS ['FORM_VIEW_FILE'] = "Просмотр файла";
$MESS ['FORM_DOWNLOAD_FILE'] = "Скачать файл #FILE_NAME#";
$MESS ['FORM_DOWNLOAD'] = "Скачать";
?>
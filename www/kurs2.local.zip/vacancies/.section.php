<?
$sSectionName = "Вакансии (Комплексный компонент)";
$arDirProperties = Array(

);
?>